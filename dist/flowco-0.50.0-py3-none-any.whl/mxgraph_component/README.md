# streamlit-custom-component

Streamlit component that allows you to do X

## Installation instructions

```sh
pip install streamlit-custom-component
```

## Usage instructions

```python
import streamlit as st

from maxgraph_component import maxgraph_component

value = maxgraph_component()

st.write(value)
```