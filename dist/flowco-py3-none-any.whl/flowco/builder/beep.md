Bootstrap the average beak length

This function has the following behavior:
- The the result output is a list of float values, each representing the mean
  beak length computed from a bootstrap sample of the `Beak length, mm` column
  in the `choose_strong` DataFrame.
- The bootstrap sampling is performed with replacement, and the number of
  bootstrap samples is a parameter that defaults to 1000.
- The the result list is used in subsequent steps for statistical analysis and
  visualization.

Args: choose_strong (DataFrame[ 'species': str  # The species of the bird. 'Beak
    length, mm': float  # The length of the beak. 'Beak depth, mm': float  # The
     depth of the beak. ]): The filtered DataFrame containing only rows for the
     'fortis' species.

        Preconditions:
        - The `choose_strong` choose_strong is a Pandas DataFrame containing only the rows from the `beaks` DataFrame where the species column has the value 'fortis'.
        - The structure of the `choose_strong` DataFrame is identical to the `beaks` DataFrame, with the same columns and data types.

    beaks (DataFrame[
     'species': str  # Automatically inferred as StrType.
     'Beak length, mm': float  # Automatically inferred as FloatType.
     'Beak depth, mm': float  # Automatically inferred as FloatType.
    ]): The DataFrame for the beaks.csv dataset.

        Preconditions:
        - The result is the dataframe for the `beaks` data set.

Returns: List[ float  # Each float represents the mean beak length from a
    bootstrap sample. ]: The output is a list of float values, each representing
     the mean beak length computed from a bootstrap sample of the `Beak length,
    mm` column in the `choose_strong` DataFrame.

