# Modification Rules


## Unlocked Nodes

* On add/remove of predecessor (immediate or indirect).

    - Flowco will modify anything necessary to make consistent computation

* On change to requirements of predecessor

    - Flowco will modify anything necessary to make consistent computation

* On user edits to node.

    - Flowco will modify anything necessary to make consistent computation

* On add/remove of successor (immediate)

    - Flowco will modify anything necessary to make consistent computation

## Locked Nodes

* On add/remove of predecessor  (immediate or indirect).

    - Flowco will warn if parameter was necessary

* On change to requirements of predecessor

    - Flowco will warn if new requirements are stronger.

* On user edits to node.

    - If in Requirements mode, Flowco can change the code.
    - Flowco will warn of any inconsistency with preds or between levels.

* On add/remove of successor (immediate).

    - Nothing?

## User edits:

* Through edit dialog for requirements/code, checks, tests.
    - These dialogs will have a suggest button to let the LLM regenerate based on current text.
* Through AMA requests.
    - Do w/out intervention?  Ask for permission???

