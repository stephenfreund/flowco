import boto3
import base64

# Set up clients for DynamoDB and KMS
dynamodb = boto3.resource("dynamodb")
kms_client = boto3.client("kms")

# Specify your DynamoDB table name and KMS key ID
TABLE_NAME = "arn:aws:dynamodb:us-east-1:925527669208:table/FlowcoApiKeys"
KMS_KEY_ID = "arn:aws:kms:us-east-1:925527669208:alias/FlowcoApiKeysKey"

table = dynamodb.Table(TABLE_NAME)


def encrypt_api_key(api_key: str) -> str:
    # Encrypt the API key using AWS KMS
    response = kms_client.encrypt(KeyId=KMS_KEY_ID, Plaintext=api_key.encode("utf-8"))
    ciphertext_blob = response["CiphertextBlob"]
    # Encode the ciphertext to store as a string in DynamoDB
    encrypted_api_key = base64.b64encode(ciphertext_blob).decode("utf-8")
    return encrypted_api_key


def decrypt_api_key(encrypted_api_key: str) -> str:
    # Decode the base64 string back to binary
    ciphertext_blob = base64.b64decode(encrypted_api_key)
    response = kms_client.decrypt(CiphertextBlob=ciphertext_blob)
    decrypted_api_key = response["Plaintext"].decode("utf-8")
    return decrypted_api_key


def store_user_api_key(email: str, api_key: str):
    encrypted_key = encrypt_api_key(api_key)
    table.put_item(
        Item={
            "email": email,
            "encrypted_api_key": encrypted_key,
            # Additional attributes (e.g., timestamps) can be added here
        }
    )
    print(f"Stored API key for {email}")


def retrieve_user_api_key(email: str) -> str:
    response = table.get_item(Key={"email": email})
    if "Item" in response:
        encrypted_key = response["Item"]["encrypted_api_key"]
        return decrypt_api_key(encrypted_key)
    else:
        raise ValueError("User not found.")


# Example usage:
if __name__ == "__main__":
    user_email = "user@example.com"
    user_api_key = "sk-XXXXXXXXXXXXXXXXXXXXXXXXXXXX"  # The API key to store

    # Store the API key
    store_user_api_key(user_email, user_api_key)

    # Retrieve and decrypt the API key
    decrypted_api_key = retrieve_user_api_key(user_email)
    print(f"Decrypted API key for {user_email}: {decrypted_api_key}")
